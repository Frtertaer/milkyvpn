import { useCallback, useEffect, useRef, useState } from "react";
import type { LocationId, VpnPhase } from "./types";
import { mapError, type UserError } from "./errors";

export interface VpnSimState {
  phase: VpnPhase;
  location: LocationId;
  /** Country actually connected to (Auto resolves to a real country). */
  connectedTo: Exclude<LocationId, "auto"> | null;
  elapsed: number; // seconds
  autoAttempt: { current: number; total: number } | null;
  error: UserError | null;
}

export interface VpnSimOptions {
  initialPhase?: VpnPhase;
  initialLocation?: LocationId;
  initialConnectedTo?: Exclude<LocationId, "auto"> | null;
  initialElapsed?: number;
  initialErrorCode?: string | null;
  /** Fail the next connect attempt with this raw code (for demos). */
  failWith?: string | null;
  frozen?: boolean; // for gallery — no timers
  isEmulator?: boolean;
  haptics?: boolean;
}

function vibrate(pattern: number | number[]) {
  try {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate(pattern);
  } catch {
    /* noop */
  }
}

export function useVpnSim(opts: VpnSimOptions = {}) {
  const [state, setState] = useState<VpnSimState>(() => ({
    phase: opts.initialPhase ?? "disconnected",
    location: opts.initialLocation ?? "auto",
    connectedTo: opts.initialConnectedTo ?? (opts.initialPhase === "connected" ? "fi" : null),
    elapsed: opts.initialElapsed ?? 0,
    autoAttempt:
      opts.initialPhase === "connecting" && (opts.initialLocation ?? "auto") === "auto" ? { current: 1, total: 4 } : null,
    error: opts.initialErrorCode ? mapError(opts.initialErrorCode, { isEmulator: opts.isEmulator, attempts: 4 }) : null,
  }));
  const timers = useRef<number[]>([]);
  const failWith = useRef<string | null | undefined>(opts.failWith);
  failWith.current = opts.failWith;
  const locationRef = useRef<LocationId>(state.location);
  locationRef.current = state.location;

  const clearTimers = () => {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
  };

  // Timer for connected state
  useEffect(() => {
    if (opts.frozen || state.phase !== "connected") return;
    const id = window.setInterval(() => setState((s) => ({ ...s, elapsed: s.elapsed + 1 })), 1000);
    return () => window.clearInterval(id);
  }, [state.phase, opts.frozen]);

  useEffect(() => () => clearTimers(), []);

  const connect = useCallback(() => {
    if (opts.haptics !== false) vibrate(12);
    clearTimers();
    setState((s) => ({
      ...s,
      phase: "connecting",
      error: null,
      elapsed: 0,
      autoAttempt: s.location === "auto" ? { current: 1, total: 4 } : null,
    }));
    if (opts.frozen) return;

    const fail = failWith.current;
    const loc = locationRef.current;
    const schedule = (ms: number, fn: () => void) => timers.current.push(window.setTimeout(fn, ms));
    const bump = (n: number) =>
      setState((x) => (x.phase === "connecting" && x.autoAttempt ? { ...x, autoAttempt: { ...x.autoAttempt, current: n } } : x));

    if (loc === "auto") {
      // Subtle progress "1 из 4" → "2 из 4" if the first candidate is slow.
      schedule(1100, () => bump(2));
      if (fail) {
        schedule(2100, () => bump(3));
        schedule(3000, () => bump(4));
      }
    }
    const doneAt = fail ? (loc === "auto" ? 3900 : 2200) : loc === "auto" ? 2600 : 2000;
    schedule(doneAt, () => {
      setState((x) => {
        if (x.phase !== "connecting") return x;
        if (fail) {
          vibrate([10, 40, 10]);
          return {
            ...x,
            phase: "error",
            autoAttempt: null,
            error: mapError(x.location === "auto" ? "all_attempts_failed" : fail, { isEmulator: opts.isEmulator, attempts: 4 }),
          };
        }
        vibrate([8, 30, 16]);
        return {
          ...x,
          phase: "connected",
          autoAttempt: null,
          connectedTo: x.location === "auto" ? "fi" : x.location,
          elapsed: 0,
        };
      });
    });
  }, [opts.frozen, opts.isEmulator, opts.haptics]);

  const disconnect = useCallback(() => {
    if (opts.haptics !== false) vibrate(8);
    clearTimers();
    setState((s) => ({ ...s, phase: "disconnected", connectedTo: null, elapsed: 0, autoAttempt: null, error: null }));
  }, [opts.haptics]);

  const phaseRef = useRef<VpnPhase>(state.phase);
  phaseRef.current = state.phase;

  const toggle = useCallback(() => {
    if (phaseRef.current === "connected" || phaseRef.current === "connecting") disconnect();
    else connect();
  }, [connect, disconnect]);

  const setLocation = useCallback(
    (loc: LocationId) => {
      if (opts.haptics !== false) vibrate(6);
      setState((s) => ({ ...s, location: loc }));
    },
    [opts.haptics],
  );

  const dismissError = useCallback(() => setState((s) => ({ ...s, phase: "disconnected", error: null })), []);

  return { state, connect, disconnect, toggle, setLocation, dismissError };
}

export type VpnSim = ReturnType<typeof useVpnSim>;

export function formatElapsed(sec: number) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const p = (n: number) => n.toString().padStart(2, "0");
  return `${p(h)}:${p(m)}:${p(s)}`;
}
