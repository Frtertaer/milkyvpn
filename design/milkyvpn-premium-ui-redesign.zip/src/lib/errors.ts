/**
 * Human-facing error mapping for MilkyVPN.
 *
 * Source of the two rejected messages in the current build:
 *
 *  1. "Не удалось выполнить операцию (proxyerror)."
 *     android/.../vpn/SafeLog.kt → errorCode(t) falls back to `t.javaClass.simpleName`.
 *     The Xray/gomobile bridge (libv2ray.aar) throws a Go-generated exception class named
 *     `proxyerror` (Go `proxy.Error` exported via gomobile) when the outbound dial fails
 *     (Reality/TLS handshake rejected, blocked port, emulator NAT). Dart side
 *     app_settings.dart → errorText(code) has no case for it → default branch prints raw code.
 *
 *  2. "Не удалось выполнить операцию (S)."
 *     Same fallback, but in a release build R8 minification renamed the Kotlin/Java exception
 *     class to a one-letter name ("S"). `simpleName` of an obfuscated class is meaningless.
 *     Fix: never derive user codes from class names; classify by cause + stage and add
 *     `-keepnames class ** extends java.lang.Throwable` to proguard for diagnostics.
 *
 * Below: raw technical code → stable diagnostic code + failure class + Russian copy.
 */

export type FailureClass =
  | "EMULATOR_FAILURE"
  | "REAL_DEVICE_FAILURE"
  | "CORE_FAILURE"
  | "CONFIG_FAILURE"
  | "PERMISSION_FAILURE"
  | "NETWORK_FAILURE";

export type ErrorAction = "retry" | "other_server" | "choose_country" | "diagnostics" | "grant_permission" | "update_subscription";

export interface UserError {
  title: string;
  body: string;
  diagnosticCode: string;
  failureClass: FailureClass;
  actions: ErrorAction[];
  rawCode: string;
}

interface Ctx {
  isEmulator?: boolean;
  attempts?: number;
}

export function mapError(rawCode: string, ctx: Ctx = {}): UserError {
  const raw = rawCode.trim();
  const code = raw.toLowerCase();
  const device: FailureClass = ctx.isEmulator ? "EMULATOR_FAILURE" : "REAL_DEVICE_FAILURE";

  // ---- permission
  if (code === "vpn_permission_denied") {
    return {
      title: "Нужно разрешение",
      body: "Android запросит разрешение на VPN-подключение. Без него защита не включится.",
      diagnosticCode: "VPN_PERMISSION_DENIED",
      failureClass: "PERMISSION_FAILURE",
      actions: ["grant_permission", "diagnostics"],
      rawCode: raw,
    };
  }

  // ---- config / subscription
  if (code === "no_compatible_profiles" || code === "no_profiles") {
    return {
      title: "Нет серверов для этой страны",
      body: "В подписке нет совместимых серверов для выбранной локации. Попробуйте «Авто» или обновите подписку.",
      diagnosticCode: "CONFIG_NO_COMPATIBLE_PROFILES",
      failureClass: "CONFIG_FAILURE",
      actions: ["choose_country", "update_subscription", "diagnostics"],
      rawCode: raw,
    };
  }
  if (code === "subscription_not_found" || code === "url_not_allowed") {
    return {
      title: "Подписка недоступна",
      body: "Не удалось загрузить список серверов. Проверьте подписку или обратитесь в поддержку.",
      diagnosticCode: "CONFIG_SUBSCRIPTION_UNAVAILABLE",
      failureClass: "CONFIG_FAILURE",
      actions: ["update_subscription", "diagnostics"],
      rawCode: raw,
    };
  }

  // ---- network
  if (code === "timeout" || code === "network_unreachable" || code === "dns_failure" || code === "connection_refused") {
    return {
      title: "Нет соединения с сервером",
      body: "Проверьте интернет и попробуйте снова. Если не помогает — выберите другой сервер.",
      diagnosticCode: `NET_${code.toUpperCase()}`,
      failureClass: "NETWORK_FAILURE",
      actions: ["retry", "other_server", "diagnostics"],
      rawCode: raw,
    };
  }

  // ---- core (Xray) — includes the infamous `proxyerror`
  if (code === "proxyerror" || code === "reality_handshake" || code === "tls_handshake" || code.startsWith("xray")) {
    return {
      title: "Не удалось подключиться",
      body: ctx.isEmulator
        ? "Сервер отклонил соединение. В эмуляторе такое бывает из-за сетевых ограничений — проверьте на реальном телефоне."
        : "Сервер отклонил соединение. Попробуем другой сервер.",
      diagnosticCode: code === "proxyerror" ? "VPN_CORE_PROXY_DIAL_FAILED" : `VPN_CORE_${code.toUpperCase()}`,
      failureClass: "CORE_FAILURE",
      actions: ["other_server", "retry", "diagnostics"],
      rawCode: raw,
    };
  }

  if (code === "tun_establish_failed") {
    return {
      title: "Не удалось создать VPN-туннель",
      body: ctx.isEmulator
        ? "Эмуляторы часто не поддерживают VpnService полностью. Проверьте на реальном устройстве."
        : "Система не позволила создать туннель. Проверьте, не включён ли другой VPN.",
      diagnosticCode: "TUN_ESTABLISH_FAILED",
      failureClass: device,
      actions: ["retry", "diagnostics"],
      rawCode: raw,
    };
  }

  if (code === "all_attempts_failed") {
    return {
      title: "Не удалось подключиться",
      body: `Мы попробовали ${ctx.attempts ?? 4} сервера — ни один не ответил. Проверьте интернет или выберите страну вручную.`,
      diagnosticCode: "AUTO_ALL_CANDIDATES_FAILED",
      failureClass: "NETWORK_FAILURE",
      actions: ["retry", "choose_country", "diagnostics"],
      rawCode: raw,
    };
  }

  // ---- obfuscated / unknown class names (e.g. "S", "a", "b1")
  const looksObfuscated = /^[a-z]{1,2}\d*$/i.test(raw);
  return {
    title: "Не удалось подключиться",
    body: "Что-то пошло не так. Попробуем ещё раз или выберем другой сервер.",
    diagnosticCode: looksObfuscated ? "UNKNOWN_NATIVE_EXCEPTION_OBFUSCATED" : "UNKNOWN_FAILURE",
    failureClass: "CORE_FAILURE",
    actions: ["retry", "other_server", "diagnostics"],
    rawCode: raw,
  };
}

export const ACTION_LABEL: Record<ErrorAction, string> = {
  retry: "Попробовать снова",
  other_server: "Другой сервер",
  choose_country: "Выбрать страну",
  diagnostics: "Диагностика",
  grant_permission: "Разрешить",
  update_subscription: "Обновить подписку",
};

export const FAILURE_CLASS_LABEL: Record<FailureClass, string> = {
  EMULATOR_FAILURE: "Ограничение эмулятора",
  REAL_DEVICE_FAILURE: "Сбой на устройстве",
  CORE_FAILURE: "Сбой ядра подключения",
  CONFIG_FAILURE: "Проблема с подпиской",
  PERMISSION_FAILURE: "Нет разрешения",
  NETWORK_FAILURE: "Проблема с сетью",
};
