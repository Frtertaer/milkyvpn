export type Theme = "light" | "dark";

export type LocationId = "auto" | "fi" | "us";

export type VpnPhase = "disconnected" | "connecting" | "connected" | "error";

export interface Location {
  id: LocationId;
  label: string;
  flag: string;
  /** Latency only when reliably measured. Never invented. */
  latencyMs?: number;
  profileCount: number;
}

export const LOCATIONS: Location[] = [
  { id: "auto", label: "Авто", flag: "✨", profileCount: 10 },
  { id: "fi", label: "Финляндия", flag: "🇫🇮", profileCount: 6 },
  { id: "us", label: "США", flag: "🇺🇸", profileCount: 4 },
];

export interface Subscription {
  active: boolean;
  expiresAt: string; // ISO
  parsedProfiles: number; // everything the parser produced
  compatibleProfiles: number; // executable by the app (Reality/WS/XHTTP/HY2)
  droppedDuplicates: number; // silently collapsed by parser id
  malformed: number;
  updatedAt: string;
}

export const DEMO_SUBSCRIPTION: Subscription = {
  active: true,
  expiresAt: "2100-01-01T00:00:00Z",
  parsedProfiles: 16,
  compatibleProfiles: 10,
  droppedDuplicates: 0,
  malformed: 0,
  updatedAt: new Date().toISOString(),
};

export type AppTab = "home" | "subscription" | "settings";
export type AppRoute = AppTab | "onboarding" | "import" | "diagnostics";
