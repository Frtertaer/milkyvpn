import type { Theme } from "../lib/types";
import {
  MilkyGlassCard,
  MilkySectionTitle,
  MilkySettingRow,
  MilkySwitch,
  IconBolt,
  IconShield,
  IconPalette,
  IconRefresh,
  IconStethoscope,
  IconChat,
  IconLock,
  IconInfo,
} from "../components/milky/MilkyPrimitives";
import { ScreenHeader } from "./ScreenHeader";

export type ThemeMode = "system" | "light" | "dark";

export function SettingsScreen({
  autoConnect,
  setAutoConnect,
  themeMode,
  setThemeMode,
  onDiagnostics,
  onRefresh,
  theme,
}: {
  autoConnect: boolean;
  setAutoConnect: (v: boolean) => void;
  themeMode: ThemeMode;
  setThemeMode: (m: ThemeMode) => void;
  onDiagnostics: () => void;
  onRefresh: () => void;
  theme: Theme;
}) {
  void theme;
  return (
    <div className="flex h-full flex-col">
      <ScreenHeader title="Настройки" />
      <div className="no-scrollbar flex-1 space-y-5 overflow-y-auto px-5 pb-4">
        <section className="anim-rise">
          <MilkySectionTitle>Подключение</MilkySectionTitle>
          <MilkyGlassCard padding="p-0" className="overflow-hidden">
            <MilkySettingRow icon={<IconBolt />} title="Автоподключение" subtitle="Включать защиту при запуске" trailing={<MilkySwitch checked={autoConnect} onChange={setAutoConnect} />} />
            <MilkySettingRow icon={<IconShield />} title="Always-on VPN" subtitle="Системные настройки Android" onClick={() => {}} last />
          </MilkyGlassCard>
        </section>

        <section className="anim-rise delay-1">
          <MilkySectionTitle>Приложение</MilkySectionTitle>
          <MilkyGlassCard padding="p-0" className="overflow-hidden">
            <div className="flex flex-wrap items-center gap-x-3.5 gap-y-2.5 border-b hairline px-4 py-3.5">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl" style={{ background: "color-mix(in oklab, var(--accent) 14%, transparent)", color: "var(--accent)" }}>
                <IconPalette />
              </span>
              <span className="t-1 min-w-[56px] flex-1 text-[15px] font-semibold">Тема</span>
              <div className="ml-auto flex shrink-0 rounded-full p-0.5" style={{ background: "color-mix(in oklab, var(--fg) 6%, transparent)" }}>
                {(["system", "light", "dark"] as ThemeMode[]).map((m) => (
                  <button
                    key={m}
                    onClick={() => setThemeMode(m)}
                    className="h-8 rounded-full px-3 text-[12.5px] font-bold transition-all"
                    style={
                      themeMode === m
                        ? { background: "var(--glass-strong)", color: "var(--fg)", boxShadow: "0 4px 12px -4px rgba(0,0,0,0.25)" }
                        : { color: "var(--fg-3)" }
                    }
                  >
                    {m === "system" ? "Авто" : m === "light" ? "Светлая" : "Тёмная"}
                  </button>
                ))}
              </div>
            </div>
            <MilkySettingRow icon={<IconRefresh />} title="Обновить подписку" subtitle="Проверить список серверов" onClick={onRefresh} last />
          </MilkyGlassCard>
        </section>

        <section className="anim-rise delay-2">
          <MilkySectionTitle>Помощь</MilkySectionTitle>
          <MilkyGlassCard padding="p-0" className="overflow-hidden">
            <MilkySettingRow icon={<IconStethoscope />} title="Диагностика" subtitle="Если что-то не работает" onClick={onDiagnostics} />
            <MilkySettingRow icon={<IconChat />} title="Поддержка" subtitle="t.me/MilkyVPNbot" onClick={() => {}} last />
          </MilkyGlassCard>
        </section>

        <section className="anim-rise delay-3">
          <MilkySectionTitle>О приложении</MilkySectionTitle>
          <MilkyGlassCard padding="p-0" className="overflow-hidden">
            <MilkySettingRow icon={<IconLock />} title="Конфиденциальность" subtitle="Без аналитики, рекламы и логов трафика" onClick={() => {}} />
            <MilkySettingRow icon={<IconInfo />} title="Версия" trailing={<span className="t-3 text-[13px] font-semibold tabular-nums">0.2.0</span>} last />
          </MilkyGlassCard>
        </section>
      </div>
    </div>
  );
}
