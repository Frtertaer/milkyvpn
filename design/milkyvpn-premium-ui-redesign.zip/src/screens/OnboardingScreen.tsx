import { useState } from "react";
import type { Theme } from "../lib/types";
import { MilkyConnectOrb } from "../components/milky/MilkyConnectOrb";
import { MilkyMark, MilkyWordmark } from "../components/milky/MilkyLogo";
import { MilkyGlassCard, MilkyPrimaryButton, MilkyTextButton, IconPhone, IconGlobe, IconArrowDown, IconLink } from "../components/milky/MilkyPrimitives";
import { cn } from "../utils/cn";

export function OnboardingScreen({ theme, onDone, onAddSubscription, initialPage = 0 }: { theme: Theme; onDone: () => void; onAddSubscription: () => void; initialPage?: number }) {
  const [page, setPage] = useState(initialPage);

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between px-6 pt-4">
        <div className="flex items-center gap-2">
          <MilkyMark size={26} id="onb" />
          <MilkyWordmark className="text-[17px]" />
        </div>
        {page < 2 && <MilkyTextButton onClick={onDone} className="h-9 px-3 text-[13px]">Пропустить</MilkyTextButton>}
      </div>

      <div className="flex flex-1 flex-col items-center justify-center px-7 text-center">
        {page === 0 && (
          <div key="p0" className="anim-rise flex flex-col items-center">
            <MilkyConnectOrb phase="disconnected" theme={theme} size={200} />
            <h1 className="t-1 mt-2 text-[28px] font-extrabold leading-[1.1] tracking-[-0.025em]">VPN без сложных настроек</h1>
            <p className="t-2 mt-3 max-w-[300px] text-[15px] leading-relaxed">Одно касание — и вы под защитой. Никаких серверов, протоколов и ключей.</p>
          </div>
        )}
        {page === 1 && (
          <div key="p1" className="anim-rise flex w-full max-w-[320px] flex-col items-center">
            <FlowIllustration />
            <h1 className="t-1 mt-8 text-[28px] font-extrabold leading-[1.1] tracking-[-0.025em]">Защищённое VPN‑соединение</h1>
            <p className="t-2 mt-3 text-[15px] leading-relaxed">Трафик телефона идёт через сервер MilkyVPN в зашифрованном туннеле. Мы не собираем историю посещений.</p>
          </div>
        )}
        {page === 2 && (
          <div key="p2" className="anim-rise flex w-full max-w-[340px] flex-col items-center">
            <h1 className="t-1 text-[28px] font-extrabold leading-[1.1] tracking-[-0.025em]">Добавьте подписку</h1>
            <p className="t-2 mt-3 text-[15px] leading-relaxed">Ссылка вида sub.milky.homes — она в вашем личном кабинете или у бота поддержки.</p>
            <MilkyGlassCard strong padding="p-5" className="relative mt-7 w-full overflow-hidden text-left">
              <div className="pointer-events-none absolute -right-14 -top-14 h-44 w-44 rounded-full blur-3xl" style={{ background: "radial-gradient(closest-side, color-mix(in oklab, var(--violet) 45%, transparent), transparent)" }} />
              <div className="relative flex items-center gap-3">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl accent-gradient text-white"><IconLink /></span>
                <div>
                  <div className="t-1 text-[16px] font-bold">Ссылка на подписку</div>
                  <div className="t-3 text-[12.5px]">Вставить из буфера или по deep link</div>
                </div>
              </div>
              <div className="relative mt-4 flex h-12 items-center rounded-2xl px-4 text-[13.5px] t-3" style={{ background: "color-mix(in oklab, var(--fg) 5%, transparent)", border: "1px dashed var(--line)" }}>
                https://sub.milky.homes/s/•••••
              </div>
            </MilkyGlassCard>
          </div>
        )}
      </div>

      <div className="px-6 pb-7">
        <div className="mb-5 flex justify-center gap-1.5">
          {[0, 1, 2].map((i) => (
            <span key={i} className={cn("h-1.5 rounded-full transition-all duration-300", i === page ? "w-6 accent-gradient" : "w-1.5")} style={i !== page ? { background: "var(--fg-3)", opacity: 0.4 } : undefined} />
          ))}
        </div>
        {page < 2 ? (
          <MilkyPrimaryButton onClick={() => setPage(page + 1)}>Продолжить</MilkyPrimaryButton>
        ) : (
          <>
            <MilkyPrimaryButton onClick={onAddSubscription}>Добавить подписку</MilkyPrimaryButton>
            <div className="mt-2 text-center"><MilkyTextButton onClick={onDone}>Помощь</MilkyTextButton></div>
          </>
        )}
      </div>
    </div>
  );
}

function FlowIllustration() {
  return (
    <div className="flex flex-col items-center gap-2">
      <Node icon={<IconPhone />} label="Телефон" />
      <span className="t-3"><IconArrowDown /></span>
      <div className="relative">
        <div className="absolute -inset-4 rounded-full blur-2xl" style={{ background: "radial-gradient(closest-side, color-mix(in oklab, var(--accent) 45%, transparent), transparent)" }} />
        <div className="glass-strong relative flex h-[68px] items-center gap-3 rounded-full pl-2 pr-5">
          <MilkyMark size={44} id="flow" />
          <span className="t-1 text-[16px] font-extrabold">MilkyVPN</span>
        </div>
      </div>
      <span className="t-3"><IconArrowDown /></span>
      <Node icon={<IconGlobe />} label="Интернет" />
    </div>
  );
}

function Node({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="glass flex items-center gap-2.5 rounded-full py-2 pl-2.5 pr-4">
      <span className="flex h-8 w-8 items-center justify-center rounded-full t-accent" style={{ background: "color-mix(in oklab, var(--accent) 14%, transparent)" }}>{icon}</span>
      <span className="t-1 text-[14px] font-bold">{label}</span>
    </div>
  );
}
