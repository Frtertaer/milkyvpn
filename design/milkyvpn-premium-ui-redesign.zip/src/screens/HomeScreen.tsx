import { LOCATIONS, type Subscription, type Theme } from "../lib/types";
import { formatElapsed, type VpnSim } from "../lib/useVpnSim";
import { MilkyConnectOrb } from "../components/milky/MilkyConnectOrb";
import { MilkyServerSelector } from "../components/milky/MilkyServerSelector";
import { MilkySubscriptionCard } from "../components/milky/MilkySubscriptionCard";
import { MilkyMark, MilkyWordmark } from "../components/milky/MilkyLogo";
import { MilkyIconButton, MilkyStatusPill, IconSettings } from "../components/milky/MilkyPrimitives";

export function HomeScreen({
  vpn,
  sub,
  theme,
  compact,
  wide,
  onOpenSubscription,
  onOpenSettings,
}: {
  vpn: VpnSim;
  sub: Subscription | null;
  theme: Theme;
  /** small phone → slightly smaller orb */
  compact: boolean;
  /** tablet column → larger orb */
  wide?: boolean;
  onOpenSubscription: () => void;
  onOpenSettings: () => void;
}) {
  const { state } = vpn;
  const connected = state.phase === "connected";
  const connecting = state.phase === "connecting";
  const country = state.connectedTo ? LOCATIONS.find((l) => l.id === state.connectedTo) : null;

  const pillTone = connected ? "on" : connecting ? "busy" : state.phase === "error" ? "warn" : "off";
  const pillText = connected ? "VPN подключён" : connecting ? "Подключаем…" : "Защита выключена";

  return (
    <div className="flex h-full flex-col">
      {/* TOP */}
      <header className={`flex items-center justify-between pt-3 ${compact ? "px-4" : "px-5"}`}>
        <div className="flex shrink-0 items-center gap-2">
          <MilkyMark size={compact ? 28 : 30} id="home" />
          <MilkyWordmark className={compact ? "text-[17px]" : "text-[19px]"} />
        </div>
        <div className="flex min-w-0 items-center gap-2">
          <MilkyStatusPill tone={pillTone} className={`min-w-0 ${compact ? "text-[12px]" : ""}`}>
            <span className="truncate">{pillText}</span>
          </MilkyStatusPill>
          <MilkyIconButton label="Настройки" onClick={onOpenSettings}>
            <IconSettings />
          </MilkyIconButton>
        </div>
      </header>

      {/* HERO */}
      <div className="flex flex-1 flex-col items-center justify-center px-5">
        <MilkyConnectOrb phase={state.phase} theme={theme} size={compact ? 200 : wide ? 272 : 236} onTap={vpn.toggle} />

        <div className="mt-1 min-h-[64px] text-center">
          {connected && country ? (
            <div className="anim-rise">
              <div className="t-1 text-[24px] font-extrabold leading-tight tracking-[-0.02em]">
                {country.flag} {country.label}
              </div>
              <div className="mt-1 flex items-center justify-center gap-2 text-[14px] font-semibold" style={{ color: "var(--success)" }}>
                Защищено
                <span className="t-3">•</span>
                <span className="t-2 tabular-nums">{formatElapsed(state.elapsed)}</span>
              </div>
            </div>
          ) : connecting ? (
            <div className="anim-rise">
              <div className="t-1 text-[22px] font-extrabold leading-tight tracking-[-0.02em]">Подключаем…</div>
              {state.autoAttempt ? (
                <div className="t-2 mt-1 text-[13.5px] font-medium">
                  Ищем лучший сервер… <span className="t-3 tabular-nums">{state.autoAttempt.current} из {state.autoAttempt.total}</span>
                </div>
              ) : (
                <div className="t-2 mt-1 text-[13.5px] font-medium">{LOCATIONS.find((l) => l.id === state.location)?.label}</div>
              )}
            </div>
          ) : (
            <div className="anim-rise">
              <div className="t-1 text-[22px] font-extrabold leading-tight tracking-[-0.02em]">Не подключено</div>
              <div className="t-3 mt-1 text-[13.5px] font-medium">Нажмите, чтобы включить защиту</div>
            </div>
          )}
        </div>
      </div>

      {/* BOTTOM STACK */}
      <div className="flex flex-col gap-3 px-5 pb-3">
        <MilkyServerSelector value={state.location} onChange={vpn.setLocation} disabled={connecting} />
        <MilkySubscriptionCard sub={sub} onClick={onOpenSubscription} />
      </div>
    </div>
  );
}
