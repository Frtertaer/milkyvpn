import type { ReactNode } from "react";
import { IconBack, MilkyIconButton } from "../components/milky/MilkyPrimitives";

export function ScreenHeader({ title, onBack, trailing }: { title: string; onBack?: () => void; trailing?: ReactNode }) {
  return (
    <header className="flex h-[60px] items-center gap-3 px-5 pt-1">
      {onBack && (
        <MilkyIconButton label="Назад" onClick={onBack}>
          <IconBack />
        </MilkyIconButton>
      )}
      <h1 className="t-1 flex-1 truncate text-[22px] font-extrabold tracking-[-0.02em]">{title}</h1>
      {trailing}
    </header>
  );
}
