import { useState } from "react";
import { DEMO_SUBSCRIPTION, type Subscription } from "../lib/types";
import { MilkyGlassCard, MilkyPrimaryButton, MilkySecondaryButton, IconClipboard, IconLink } from "../components/milky/MilkyPrimitives";
import { ScreenHeader } from "./ScreenHeader";
import { plural } from "./SubscriptionScreen";

type Stage = "input" | "parsing" | "success";

export function ImportScreen({ onBack, onImported, initialStage = "input" }: { onBack?: () => void; onImported: (s: Subscription) => void; initialStage?: Stage }) {
  const [stage, setStage] = useState<Stage>(initialStage);
  const [value, setValue] = useState(initialStage === "input" ? "" : "https://sub.milky.homes/s/•••••••");
  const [sub] = useState<Subscription>(DEMO_SUBSCRIPTION);

  const valid = /^https:\/\/sub\.milky\.homes\/s\/[A-Za-z0-9_•-]+$/.test(value.trim());

  const start = () => {
    setStage("parsing");
    setTimeout(() => setStage("success"), 1400);
  };

  if (stage === "success") {
    const unsupported = sub.parsedProfiles - sub.compatibleProfiles;
    return (
      <div className="flex h-full flex-col">
        <div className="flex flex-1 flex-col items-center justify-center px-7 text-center">
          <div className="relative flex h-[160px] w-[160px] items-center justify-center">
            <div className="anim-ring-pulse absolute inset-0 rounded-full" style={{ border: "1.5px solid var(--success)" }} />
            <div className="anim-pop flex h-[112px] w-[112px] items-center justify-center rounded-full" style={{ background: "linear-gradient(135deg, var(--success), var(--accent-2))", boxShadow: "0 30px 60px -20px var(--success)" }}>
              <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="#0a0f22" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round">
                <path className="anim-check" d="m5 12.5 4.5 4.5L19 7.5" />
              </svg>
            </div>
          </div>
          <h1 className="t-1 anim-rise delay-2 mt-4 text-[26px] font-extrabold tracking-[-0.025em]">Подписка добавлена</h1>
          <MilkyGlassCard className="anim-rise delay-3 mt-6 w-full max-w-[320px]" padding="p-4">
            <div className="flex items-center justify-between">
              <span className="t-2 text-[14px]">Найдено</span>
              <span className="t-1 text-[15px] font-extrabold">{sub.parsedProfiles} {plural(sub.parsedProfiles, "профиль", "профиля", "профилей")}</span>
            </div>
            <div className="mt-2 flex items-center justify-between border-t hairline pt-2">
              <span className="t-2 text-[14px]">Поддерживаются</span>
              <span className="t-accent text-[15px] font-extrabold">{sub.compatibleProfiles}</span>
            </div>
            {unsupported > 0 && <p className="t-3 mt-2 text-left text-[12px] leading-snug">{unsupported} на протоколах, которые приложение пока не использует.</p>}
          </MilkyGlassCard>
        </div>
        <div className="px-6 pb-7 anim-rise delay-4">
          <MilkyPrimaryButton onClick={() => onImported(sub)}>Перейти к подключению</MilkyPrimaryButton>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <ScreenHeader title="Добавить подписку" onBack={onBack} />
      <div className="flex flex-1 flex-col px-5">
        <MilkyGlassCard strong padding="p-5" className="anim-rise">
          <label className="t-3 text-[12px] font-bold uppercase tracking-[0.12em]">Ссылка на подписку</label>
          <div className="mt-2 flex h-[52px] items-center gap-2 rounded-2xl px-4" style={{ background: "color-mix(in oklab, var(--fg) 5%, transparent)", border: "1px solid var(--line)" }}>
            <span className="t-3"><IconLink /></span>
            <input
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="https://sub.milky.homes/s/…"
              className="t-1 h-full flex-1 bg-transparent text-[14.5px] outline-none placeholder:text-[var(--fg-3)]"
              spellCheck={false}
              disabled={stage === "parsing"}
            />
          </div>
          <MilkySecondaryButton size="md" className="mt-3" onClick={() => setValue("https://sub.milky.homes/s/•••••••")} disabled={stage === "parsing"}>
            <span className="inline-flex items-center gap-2"><IconClipboard />Вставить из буфера</span>
          </MilkySecondaryButton>
          <p className="t-3 mt-4 text-[12.5px] leading-snug">
            Принимаются только ссылки sub.milky.homes. Токен хранится в защищённом хранилище и не покидает устройство.
          </p>
        </MilkyGlassCard>

        <div className="anim-rise delay-1 mt-5 flex items-center gap-3 px-1">
          <span className="t-3 text-[12.5px]">Или откройте ссылку <span className="t-2 font-semibold">milkyvpn://import</span> из бота поддержки</span>
        </div>

        <div className="mt-auto pb-7">
          <MilkyPrimaryButton disabled={!valid || stage === "parsing"} onClick={start}>
            {stage === "parsing" ? (
              <span className="inline-flex items-center gap-2">
                <span className="anim-spin inline-block h-4 w-4 rounded-full border-2 border-white/40 border-t-white" />
                Проверяем…
              </span>
            ) : (
              "Добавить"
            )}
          </MilkyPrimaryButton>
        </div>
      </div>
    </div>
  );
}
