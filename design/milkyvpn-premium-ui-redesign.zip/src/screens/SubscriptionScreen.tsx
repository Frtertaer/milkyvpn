import { useState } from "react";
import type { Subscription } from "../lib/types";
import { formatDate } from "../components/milky/MilkySubscriptionCard";
import {
  MilkyGlassCard,
  MilkyPrimaryButton,
  MilkySecondaryButton,
  MilkySettingRow,
  IconCopy,
  IconRefresh,
  IconTrash,
  IconInfo,
} from "../components/milky/MilkyPrimitives";
import { ScreenHeader } from "./ScreenHeader";

export function SubscriptionScreen({
  sub,
  onRefresh,
  onDelete,
  onAdd,
}: {
  sub: Subscription | null;
  onRefresh: () => void;
  onDelete: () => void;
  onAdd: () => void;
}) {
  const [advanced, setAdvanced] = useState(false);
  const [copied, setCopied] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const refresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
      onRefresh();
    }, 1200);
  };

  if (!sub) {
    return (
      <div className="flex h-full flex-col">
        <ScreenHeader title="Подписка" />
        <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
          <div className="t-1 text-[20px] font-extrabold">Подписка не добавлена</div>
          <p className="t-2 mt-2 max-w-[300px] text-[14px]">Добавьте ссылку Milky, чтобы получить список серверов.</p>
          <MilkyPrimaryButton className="mt-6 max-w-[300px]" onClick={onAdd}>Добавить подписку</MilkyPrimaryButton>
        </div>
      </div>
    );
  }

  const dropped = sub.parsedProfiles - sub.compatibleProfiles;

  return (
    <div className="flex h-full flex-col">
      <ScreenHeader title="Подписка" />
      <div className="no-scrollbar flex-1 overflow-y-auto px-5 pb-4">
        {/* Large status card */}
        <MilkyGlassCard strong padding="p-5" className="relative overflow-hidden anim-rise">
          <div
            className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full blur-3xl"
            style={{ background: "radial-gradient(closest-side, color-mix(in oklab, var(--success) 40%, transparent), transparent)" }}
          />
          <div className="relative flex items-start justify-between">
            <div>
              <div className="t-3 text-[12px] font-bold uppercase tracking-[0.12em]">Milky</div>
              <div className="t-1 mt-1 text-[26px] font-extrabold leading-none tracking-[-0.02em]">Подписка</div>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12.5px] font-bold" style={{ background: "color-mix(in oklab, var(--success) 16%, transparent)", color: "var(--success)" }}>
              <span className="h-2 w-2 rounded-full" style={{ background: "var(--success)" }} />
              {sub.active ? "Активна" : "Истекла"}
            </span>
          </div>

          <div className="relative mt-6 grid grid-cols-2 gap-3">
            <Stat label="Действует до" value={formatDate(sub.expiresAt)} />
            <Stat label="Обновлено" value="только что" />
            <Stat label="Профилей в подписке" value={String(sub.parsedProfiles)} />
            <Stat label="Совместимых с приложением" value={String(sub.compatibleProfiles)} accent />
          </div>

          {dropped > 0 && (
            <div className="relative mt-4 flex items-start gap-2.5 rounded-2xl p-3" style={{ background: "color-mix(in oklab, var(--accent) 10%, transparent)" }}>
              <span className="t-accent mt-0.5 shrink-0"><IconInfo /></span>
              <p className="t-2 text-[12.5px] leading-snug">
                {dropped} {plural(dropped, "профиль", "профиля", "профилей")} используют протоколы, которые приложение пока не поддерживает. Они не мешают подключению.
              </p>
            </div>
          )}
        </MilkyGlassCard>

        {/* Actions */}
        <div className="mt-4 flex gap-2.5 anim-rise delay-1">
          <MilkyPrimaryButton onClick={refresh} disabled={refreshing}>
            <span className="inline-flex items-center gap-2">
              <span className={refreshing ? "anim-spin" : ""}><IconRefresh /></span>
              {refreshing ? "Обновляем…" : "Обновить"}
            </span>
          </MilkyPrimaryButton>
          <MilkySecondaryButton block={false} onClick={onDelete} className="shrink-0 px-5" aria-label="Удалить подписку">
            <span className="inline-flex items-center gap-2 t-danger"><IconTrash />Удалить</span>
          </MilkySecondaryButton>
        </div>

        {/* Advanced */}
        <div className="mt-6 anim-rise delay-2">
          <button onClick={() => setAdvanced((v) => !v)} className="t-3 ml-1 flex items-center gap-1 text-[12px] font-bold uppercase tracking-[0.12em]">
            Дополнительно
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} className={`transition-transform ${advanced ? "rotate-180" : ""}`}><path d="m6 9 6 6 6-6" /></svg>
          </button>
          {advanced && (
            <MilkyGlassCard padding="p-0" className="mt-2 overflow-hidden anim-fade">
              <MilkySettingRow
                icon={<IconCopy />}
                title={copied ? "Скопировано" : "Скопировать ссылку"}
                subtitle="Ссылка содержит ваш токен — не делитесь ею"
                onClick={() => {
                  setCopied(true);
                  setTimeout(() => setCopied(false), 1500);
                }}
                last
              />
            </MilkyGlassCard>
          )}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-2xl p-3" style={{ background: "color-mix(in oklab, var(--fg) 4%, transparent)" }}>
      <div className="t-3 text-[11.5px] font-semibold leading-tight">{label}</div>
      <div className={`mt-1 text-[16px] font-extrabold leading-tight tracking-[-0.01em] ${accent ? "t-accent" : "t-1"}`}>{value}</div>
    </div>
  );
}

export function plural(n: number, one: string, few: string, many: string) {
  const m10 = n % 10, m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return few;
  return many;
}
