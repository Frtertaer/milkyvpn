import { useState } from "react";
import { FAILURE_CLASS_LABEL, type UserError } from "../lib/errors";
import type { Subscription } from "../lib/types";
import { MilkyGlassCard, MilkyPrimaryButton, MilkySectionTitle, IconCopy } from "../components/milky/MilkyPrimitives";
import { ScreenHeader } from "./ScreenHeader";

/** The ONLY place where technical codes are allowed to appear. */
export function DiagnosticsScreen({ onBack, lastError, sub, isEmulator }: { onBack: () => void; lastError: UserError | null; sub: Subscription | null; isEmulator: boolean }) {
  const [copied, setCopied] = useState(false);
  const rows: [string, string][] = [
    ["Устройство", isEmulator ? "Эмулятор (LDPlayer / x86)" : "Реальное устройство"],
    ["Android", "14 (API 34)"],
    ["Версия приложения", "0.2.0 (build 12)"],
    ["Ядро", "Xray-core 1.260327.1"],
    ["Профилей разобрано", sub ? `${sub.parsedProfiles} (повреждённых: ${sub.malformed})` : "—"],
    ["Совместимых", sub ? String(sub.compatibleProfiles) : "—"],
    ["Отброшено как дубли", sub ? String(sub.droppedDuplicates) : "—"],
  ];

  return (
    <div className="flex h-full flex-col">
      <ScreenHeader title="Диагностика" onBack={onBack} />
      <div className="no-scrollbar flex-1 space-y-5 overflow-y-auto px-5 pb-4">
        {lastError && (
          <section className="anim-rise">
            <MilkySectionTitle>Последняя ошибка</MilkySectionTitle>
            <MilkyGlassCard strong padding="p-4">
              <div className="flex items-center justify-between gap-3">
                <span className="t-1 text-[15px] font-bold">{lastError.title}</span>
                <span className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold" style={{ background: "color-mix(in oklab, var(--warn) 18%, transparent)", color: "var(--warn)" }}>
                  {lastError.failureClass}
                </span>
              </div>
              <p className="t-2 mt-1 text-[13px]">{FAILURE_CLASS_LABEL[lastError.failureClass]}</p>
              <div className="mt-3 space-y-1.5 rounded-xl p-3 font-mono text-[12px]" style={{ background: "color-mix(in oklab, var(--fg) 5%, transparent)" }}>
                <div className="flex justify-between gap-3"><span className="t-3">Код диагностики</span><span className="t-1 font-semibold">{lastError.diagnosticCode}</span></div>
                <div className="flex justify-between gap-3"><span className="t-3">Внутренний код</span><span className="t-2">{lastError.rawCode}</span></div>
                <div className="flex justify-between gap-3"><span className="t-3">Стадия</span><span className="t-2">xray.startLoop → dial</span></div>
              </div>
            </MilkyGlassCard>
          </section>
        )}

        <section className="anim-rise delay-1">
          <MilkySectionTitle>Окружение</MilkySectionTitle>
          <MilkyGlassCard padding="p-0" className="overflow-hidden">
            {rows.map(([k, v], i) => (
              <div key={k} className={`flex items-center justify-between gap-3 px-4 py-3 ${i < rows.length - 1 ? "border-b hairline" : ""}`}>
                <span className="t-2 text-[13.5px]">{k}</span>
                <span className="t-1 text-right text-[13.5px] font-semibold">{v}</span>
              </div>
            ))}
          </MilkyGlassCard>
        </section>

        <section className="anim-rise delay-2">
          <MilkySectionTitle>Классы сбоев</MilkySectionTitle>
          <MilkyGlassCard padding="p-4">
            <ul className="t-2 space-y-1.5 text-[12.5px] leading-snug">
              {(Object.keys(FAILURE_CLASS_LABEL) as (keyof typeof FAILURE_CLASS_LABEL)[]).map((k) => (
                <li key={k} className="flex gap-2"><span className="t-3 font-mono">{k}</span><span>— {FAILURE_CLASS_LABEL[k]}</span></li>
              ))}
            </ul>
          </MilkyGlassCard>
        </section>

        <MilkyPrimaryButton className="anim-rise delay-3" onClick={() => { setCopied(true); setTimeout(() => setCopied(false), 1500); }}>
          <span className="inline-flex items-center gap-2"><IconCopy />{copied ? "Скопировано" : "Скопировать диагностику"}</span>
        </MilkyPrimaryButton>
        <p className="t-3 text-center text-[11.5px]">Учётные данные и токены удаляются автоматически</p>
      </div>
    </div>
  );
}
