import { DesignReview } from "./app/DesignReview";

export default function App() {
  return <DesignReview />;
}
