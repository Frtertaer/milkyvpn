export interface ReportSection {
  title: string;
  rows: [string, string][];
}

export const REPORT_STATUS = "PREMIUM_UI_PROTOTYPE_COMPLETE — BLOCKED for Flutter build: this environment has no Flutter/Android SDK; the design system, screens, error mapping and investigation below are ready to port 1:1 into lib/ui/.";

export const REPORT: ReportSection[] = [
  {
    title: "DESIGN",
    rows: [
      ["visual concept", "«Milky Glass»: тёмная полночь / тёплое молоко, две мягкие аврора-подсветки (blue→violet→cyan), матовые стеклянные карточки (blur 22–28, hairline inset-highlight), скруглённая геометрия 18–30, Manrope (кириллица), сдержанное свечение."],
      ["signature component", "MilkyConnectOrb — молочная стеклянная сфера в конусном градиентном кольце: дыхание (idle) → вращающееся «жидкое» кольцо (connecting) → teal/cyan подсветка + анимированная галочка + расходящиеся protected-rings (connected)."],
      ["custom widgets", "MilkyGlassCard, MilkyPrimaryButton/Secondary/Text, MilkyConnectOrb, MilkyServerSelector, MilkyStatusPill, MilkySettingRow, MilkySwitch, MilkyNavigationBar, MilkySubscriptionCard, MilkyErrorSheet, MilkyBackground, MilkyMark/MilkyAppIcon."],
      ["icon", "Абстрактная капля молока с гребнем-«M» (белая волна), аврора-градиент, тёмная сквиркл-подложка. Без замка и глобуса. Читается на 48px (см. галерею)."],
      ["dark/light", "Два отдельных набора токенов (не инверсия): dark = #0a0f22 + glass 5–9% white + свечения; light = #f6f3ee + белое стекло 62–86% + голубо-фиолетовые тени."],
    ],
  },
  {
    title: "HOME",
    rows: [
      ["disconnected", "Логотип + MilkyStatusPill «Защита выключена» + кнопка настроек. Orb приглушён, медленно дышит. «Не подключено / Нажмите, чтобы включить защиту». Ниже — селектор локаций и компактная карточка подписки. Bottom nav: Главная · Подписка · Настройки."],
      ["connecting", "Кольцо вращается, второе встречное кольцо создаёт «жидкий» ореол. «Подключаем…» и для Авто — «Ищем лучший сервер… 1 из 4». Селектор заблокирован."],
      ["connected", "Аврора меняется на teal/cyan, orb светится, галочка рисуется stroke-анимацией, два расходящихся кольца. «🇫🇮 Финляндия / Защищено • 00:14:32». Никаких протоколов."],
      ["location selector", "Три стеклянных чипа: ✨ Авто (по умолчанию) · 🇫🇮 Финляндия · 🇺🇸 США. Выбранный — сильное стекло, градиентная обводка, свечение, галочка. Latency показывается только если latencyMs реально измерен — иначе кол-во серверов."],
    ],
  },
  {
    title: "SUBSCRIPTION (investigation)",
    rows: [
      ["total parsed profiles", "Текущий UI выводит snapshot.profiles.length (main.dart:301, :477), подписанный как «Количество доступных серверов». Для production-подписки это значение = 10, т.е. парсер вернул 10, а не 16."],
      ["executable compatible profiles", "vpn.compatibleCount считается отдельно (VpnController.supportedProfiles → bridge.isProfileSupported) и в UI нигде не показывался, только в диагностике («Compatible profiles»)."],
      ["reason UI showed 10", "Наиболее вероятно вариант C (тихая потеря), а не D: в SubscriptionParser.parse() записи дедуплицируются по p.id = fnv1a64('proto|host|port|network|security|path') — SNI, UUID, flow, remark, headerType, obfs в ключ НЕ входят. Профили одного хоста:порта с тем же транспортом (напр. несколько Reality/XHTTP на 443 с разными SNI или несколькими UUID) схлопываются `if (seen.add(p.id))` без счётчика. Фикстура subscription_16_fake содержит 16 уникальных хостов — поэтому тесты проходят на 16, а прод даёт 10. Дополнительно строки с неизвестной схемой → parseLine()==null → malformed (тоже скрыто). Требуется подтвердить на реальной подписке: добавить в парсер счётчик droppedDuplicates и включить в id fragment/uuid-hash/sni. Новый UI показывает честно «16 профилей • 10 совместимых» только когда оба числа известны; в прототипе это демо-значения."],
    ],
  },
  {
    title: "ERROR UX",
    rows: [
      ["proxyerror source", "SafeLog.errorCode(t): при отсутствии совпадений по тексту возвращает t.javaClass.simpleName. Исключение приходит из libv2ray.aar (gomobile-обёртка Xray): Go-тип proxy.Error экспортируется классом `proxyerror` при неудачном outbound dial (Reality/TLS handshake отклонён, порт заблокирован, NAT эмулятора). Dart: AppStrings.errorText(code) не знает код → default → «Не удалось выполнить операцию (proxyerror)»."],
      ["\"(S)\" source", "Тот же fallback simpleName, но в release-сборке R8 переименовал класс исключения в `S`. Имя обфусцированного класса как код ошибки бессмысленно. Фикс: классифицировать по стадии (prepare/resolve/tun/xray.start/probe) + cause, а не по имени класса; в proguard добавить -keepnames для Throwable-наследников ради диагностики."],
      ["new user-facing mapping", "lib/errors.ts → mapError(raw, {isEmulator}): proxyerror → «Не удалось подключиться / Сервер отклонил соединение. Попробуем другой сервер.» (VPN_CORE_PROXY_DIAL_FAILED, CORE_FAILURE); S/обфусцированные → UNKNOWN_NATIVE_EXCEPTION_OBFUSCATED; timeout/dns/refused → «Нет соединения с сервером» (NETWORK_FAILURE); tun_establish_failed → EMULATOR_FAILURE или REAL_DEVICE_FAILURE; permission → PERMISSION_FAILURE; no_compatible/url → CONFIG_FAILURE. Кнопки: Попробовать снова · Другой сервер · Выбрать страну; «Диагностика» — текстовая ссылка. Код только на экране Диагностики."],
    ],
  },
  {
    title: "RESPONSIVE",
    rows: [
      ["phone", "360×720: orb 200, тексты 22/13.5, nav и чипы влезают без обрезки русских строк. 412×892: orb 236."],
      ["tablet", "800×1180: фон на всю ширину, интерактивная колонка ограничена maxContentWidth=560 и центрирована; ничего не растягивается на весь экран."],
    ],
  },
  {
    title: "TESTS / BUILD (для Flutter-переноса)",
    rows: [
      ["analyze / flutter test / Android", "Не выполнялись — в этой среде нет Flutter SDK. Функциональная логика (parser, secure store, bridge) прототипом не затрагивается."],
      ["golden/widget plan", "home_disconnected, home_connecting, home_connected_fi, home_connected_us, server_selector, subscription, settings, error_sheet × {light, dark} × {360×720, 412×892, 800×1180}; overflow-тест русских строк на 360dp с textScale 1.3."],
      ["APK / AAB", "Не собирались (BLOCKED: нет SDK). VPN functionality changed: NO. Still requires retest on real device: YES."],
    ],
  },
];
