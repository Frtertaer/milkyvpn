import { useEffect, useState } from "react";
import { DEMO_SUBSCRIPTION, type AppRoute, type AppTab, type LocationId, type Subscription, type Theme, type VpnPhase } from "../lib/types";
import { useVpnSim } from "../lib/useVpnSim";
import type { ErrorAction, UserError } from "../lib/errors";
import { MilkyBackground } from "../components/milky/MilkyBackground";
import { MilkyNavigationBar } from "../components/milky/MilkyNavigationBar";
import { MilkyErrorSheet } from "../components/milky/MilkyErrorSheet";
import { HomeScreen } from "../screens/HomeScreen";
import { SubscriptionScreen } from "../screens/SubscriptionScreen";
import { SettingsScreen, type ThemeMode } from "../screens/SettingsScreen";
import { OnboardingScreen } from "../screens/OnboardingScreen";
import { ImportScreen } from "../screens/ImportScreen";
import { DiagnosticsScreen } from "../screens/DiagnosticsScreen";

export interface MilkyAppPreset {
  route?: AppRoute;
  onboardingPage?: number;
  importStage?: "input" | "parsing" | "success";
  phase?: VpnPhase;
  location?: LocationId;
  connectedTo?: "fi" | "us" | null;
  elapsed?: number;
  errorCode?: string | null;
  hasSubscription?: boolean;
}

export interface MilkyAppProps {
  theme: Theme;
  preset?: MilkyAppPreset;
  frozen?: boolean;
  failWith?: string | null;
  isEmulator?: boolean;
  reducedMotion?: boolean;
  width: number;
  height: number;
  onThemeModeChange?: (m: ThemeMode) => void;
  themeMode?: ThemeMode;
}

export function MilkyApp({ theme, preset = {}, frozen, failWith, isEmulator, reducedMotion, width, height, onThemeModeChange, themeMode = "system" }: MilkyAppProps) {
  const [route, setRoute] = useState<AppRoute>(preset.route ?? "home");
  const [sub, setSub] = useState<Subscription | null>(preset.hasSubscription === false ? null : DEMO_SUBSCRIPTION);
  const [autoConnect, setAutoConnect] = useState(false);
  const [lastError, setLastError] = useState<UserError | null>(null);

  const vpn = useVpnSim({
    initialPhase: preset.phase,
    initialLocation: preset.location,
    initialConnectedTo: preset.connectedTo,
    initialElapsed: preset.elapsed,
    initialErrorCode: preset.errorCode,
    frozen,
    failWith,
    isEmulator,
  });

  useEffect(() => {
    if (vpn.state.error) setLastError(vpn.state.error);
  }, [vpn.state.error]);

  const tab: AppTab = route === "home" || route === "subscription" || route === "settings" ? route : "home";
  const showNav = route === "home" || route === "subscription" || route === "settings";
  const compact = height < 760;
  const isTablet = width >= 600;

  const onErrorAction = (a: ErrorAction) => {
    switch (a) {
      case "retry":
        vpn.connect();
        break;
      case "other_server":
        vpn.setLocation(vpn.state.location === "fi" ? "us" : "fi");
        vpn.connect();
        break;
      case "choose_country":
        vpn.dismissError();
        setRoute("home");
        break;
      case "diagnostics":
        vpn.dismissError();
        setRoute("diagnostics");
        break;
      case "update_subscription":
        vpn.dismissError();
        setRoute("subscription");
        break;
      case "grant_permission":
        vpn.dismissError();
        break;
    }
  };

  return (
    <div
      className="milky relative flex h-full w-full flex-col overflow-hidden"
      data-theme={theme}
      data-motion={reducedMotion ? "reduced" : "full"}
      style={{ width, height }}
    >
      <MilkyBackground phase={vpn.state.phase} theme={theme} />

      {/* Status bar spacer */}
      <div className="relative z-10 flex h-8 shrink-0 items-center justify-between px-6 text-[12px] font-semibold t-2">
        <span>9:41</span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block h-2.5 w-2.5 rounded-sm" style={{ background: "currentColor", opacity: 0.6 }} />
          <span className="inline-block h-2.5 w-4 rounded-sm" style={{ background: "currentColor", opacity: 0.6 }} />
        </span>
      </div>

      {/* Content column: never stretches on tablets */}
      <div className="relative z-10 mx-auto flex min-h-0 w-full flex-1 flex-col" style={{ maxWidth: isTablet ? 560 : undefined }}>
        <div className="min-h-0 flex-1">
          {route === "onboarding" && <OnboardingScreen theme={theme} initialPage={preset.onboardingPage} onDone={() => setRoute("home")} onAddSubscription={() => setRoute("import")} />}
          {route === "import" && (
            <ImportScreen
              initialStage={preset.importStage}
              onBack={() => setRoute(sub ? "subscription" : "onboarding")}
              onImported={(s) => {
                setSub(s);
                setRoute("home");
              }}
            />
          )}
          {route === "diagnostics" && <DiagnosticsScreen onBack={() => setRoute("settings")} lastError={lastError} sub={sub} isEmulator={!!isEmulator} />}
          {route === "home" && (
            <HomeScreen vpn={vpn} sub={sub} theme={theme} compact={compact} wide={isTablet} onOpenSubscription={() => setRoute(sub ? "subscription" : "import")} onOpenSettings={() => setRoute("settings")} />
          )}
          {route === "subscription" && (
            <SubscriptionScreen sub={sub} onRefresh={() => {}} onDelete={() => setSub(null)} onAdd={() => setRoute("import")} />
          )}
          {route === "settings" && (
            <SettingsScreen
              theme={theme}
              autoConnect={autoConnect}
              setAutoConnect={setAutoConnect}
              themeMode={themeMode}
              setThemeMode={(m) => onThemeModeChange?.(m)}
              onDiagnostics={() => setRoute("diagnostics")}
              onRefresh={() => setRoute("subscription")}
            />
          )}
        </div>

        {showNav && (
          <div className="shrink-0 px-5 pb-5 pt-2">
            <MilkyNavigationBar value={tab} onChange={(t) => setRoute(t)} />
          </div>
        )}
      </div>

      {vpn.state.phase === "error" && vpn.state.error && (
        <MilkyErrorSheet error={vpn.state.error} onAction={onErrorAction} onClose={vpn.dismissError} />
      )}
    </div>
  );
}
