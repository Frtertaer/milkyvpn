import type { ReactNode } from "react";

export type DeviceId = "small" | "large" | "tablet";

export const DEVICES: Record<DeviceId, { label: string; w: number; h: number; radius: number }> = {
  small: { label: "Small phone · 360×720", w: 360, h: 720, radius: 34 },
  large: { label: "Large phone · 412×892", w: 412, h: 892, radius: 40 },
  tablet: { label: "Tablet · 800×1180", w: 800, h: 1180, radius: 28 },
};

/** Device chrome. Content is rendered at native dp size, then scaled by parent. */
export function PhoneFrame({ device, scale = 1, children, caption }: { device: DeviceId; scale?: number; children: ReactNode; caption?: string }) {
  const d = DEVICES[device];
  const bezel = device === "tablet" ? 14 : 10;
  return (
    <div className="flex flex-col items-center gap-3">
      <div style={{ width: (d.w + bezel * 2) * scale, height: (d.h + bezel * 2) * scale }}>
        <div
          className="relative origin-top-left"
          style={{
            width: d.w + bezel * 2,
            height: d.h + bezel * 2,
            transform: `scale(${scale})`,
            borderRadius: d.radius + bezel,
            padding: bezel,
            background: "linear-gradient(160deg, #262b45 0%, #0d1024 60%, #1b2040 100%)",
            boxShadow: "0 40px 90px -30px rgba(0,0,0,0.85), inset 0 1px 0 rgba(255,255,255,0.14), 0 0 0 1px rgba(255,255,255,0.06)",
          }}
        >
          <div className="relative overflow-hidden" style={{ width: d.w, height: d.h, borderRadius: d.radius }}>
            {children}
            {device !== "tablet" && (
              <div className="pointer-events-none absolute left-1/2 top-2 z-50 h-[10px] w-[10px] -translate-x-1/2 rounded-full bg-black/90 ring-2 ring-black/40" />
            )}
          </div>
        </div>
      </div>
      {caption && <div className="text-[12px] font-semibold text-white/55">{caption}</div>}
    </div>
  );
}
