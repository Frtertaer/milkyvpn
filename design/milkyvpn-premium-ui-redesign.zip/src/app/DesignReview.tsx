import { useEffect, useMemo, useState } from "react";
import { MilkyApp, type MilkyAppPreset } from "./MilkyApp";
import { DEVICES, PhoneFrame, type DeviceId } from "./PhoneFrame";
import { REPORT, REPORT_STATUS } from "./reportContent";
import { MilkyAppIcon, MilkyMark } from "../components/milky/MilkyLogo";
import type { Theme } from "../lib/types";
import type { ThemeMode } from "../screens/SettingsScreen";
import { cn } from "../utils/cn";

type Mode = "interactive" | "gallery" | "report";

const SCENARIOS: { id: string; label: string; preset: MilkyAppPreset; failWith?: string | null }[] = [
  { id: "onb", label: "Онбординг", preset: { route: "onboarding" } },
  { id: "home", label: "Главная", preset: { route: "home" } },
  { id: "fail", label: "Сбой (proxyerror)", preset: { route: "home", location: "fi" }, failWith: "proxyerror" },
  { id: "fail-auto", label: "Авто: все попытки", preset: { route: "home", location: "auto" }, failWith: "S" },
  { id: "import", label: "Импорт", preset: { route: "import", hasSubscription: false } },
  { id: "sub", label: "Подписка", preset: { route: "subscription" } },
  { id: "settings", label: "Настройки", preset: { route: "settings" } },
];

const GALLERY: { caption: string; theme: Theme; device: DeviceId; preset: MilkyAppPreset }[] = [
  { caption: "1 · Onboarding", theme: "light", device: "large", preset: { route: "onboarding" } },
  { caption: "2 · Home · disconnected", theme: "light", device: "large", preset: { route: "home" } },
  { caption: "3 · Connecting (Авто)", theme: "light", device: "large", preset: { route: "home", phase: "connecting", location: "auto" } },
  { caption: "4 · Connected · Finland", theme: "light", device: "large", preset: { route: "home", phase: "connected", location: "fi", connectedTo: "fi", elapsed: 872 } },
  { caption: "5 · Connected · USA", theme: "dark", device: "large", preset: { route: "home", phase: "connected", location: "us", connectedTo: "us", elapsed: 3721 } },
  { caption: "6 · Subscription", theme: "light", device: "large", preset: { route: "subscription" } },
  { caption: "7 · Settings", theme: "dark", device: "large", preset: { route: "settings" } },
  { caption: "8 · Failure sheet", theme: "light", device: "large", preset: { route: "home", phase: "error", location: "fi", errorCode: "proxyerror" } },
  { caption: "9 · Dark home", theme: "dark", device: "large", preset: { route: "home" } },
  { caption: "+ Import success", theme: "dark", device: "large", preset: { route: "import", importStage: "success", hasSubscription: false } },
  { caption: "+ Small phone 360", theme: "light", device: "small", preset: { route: "home", phase: "connected", connectedTo: "fi", elapsed: 61 } },
  { caption: "+ Tablet 800 (maxWidth 560)", theme: "dark", device: "tablet", preset: { route: "home" } },
];

function useViewport() {
  const [v, setV] = useState({ w: window.innerWidth, h: window.innerHeight });
  useEffect(() => {
    const on = () => setV({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, []);
  return v;
}

export function DesignReview() {
  const [mode, setMode] = useState<Mode>("interactive");
  const [themeMode, setThemeMode] = useState<ThemeMode>("dark");
  const [device, setDevice] = useState<DeviceId>("large");
  const [scenario, setScenario] = useState(SCENARIOS[1]);
  const [isEmulator, setIsEmulator] = useState(false);
  const [reduced, setReduced] = useState(false);
  const [key, setKey] = useState(0);
  const vp = useViewport();

  const systemDark = window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? true;
  const theme: Theme = themeMode === "system" ? (systemDark ? "dark" : "light") : themeMode;

  const d = DEVICES[device];
  const scale = useMemo(() => Math.min(1, (vp.h - 150) / (d.h + 20), (vp.w - 420) / (d.w + 20)), [vp, d]);

  const pick = (s: (typeof SCENARIOS)[number]) => {
    setScenario(s);
    setKey((k) => k + 1);
  };

  return (
    <div className="min-h-screen" style={{ background: "radial-gradient(120% 90% at 50% -20%, #151b3d 0%, #07091a 60%)" }}>
      {/* Top bar */}
      <div className="sticky top-0 z-30 flex items-center justify-between border-b border-white/8 bg-[#07091a]/80 px-5 py-3 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <MilkyMark size={30} id="shell" />
          <div>
            <div className="text-[15px] font-extrabold tracking-tight">MilkyVPN · Milky Glass</div>
            <div className="text-[11.5px] text-white/50">UI/UX redesign prototype — interactive spec for the Flutter port</div>
          </div>
        </div>
        <div className="flex rounded-full bg-white/6 p-1 ring-1 ring-white/8">
          {(["interactive", "gallery", "report"] as Mode[]).map((m) => (
            <button key={m} onClick={() => setMode(m)} className={cn("h-9 rounded-full px-4 text-[13px] font-bold transition-all", mode === m ? "bg-white text-[#0a0f22] shadow" : "text-white/60 hover:text-white")}>
              {m === "interactive" ? "Интерактив" : m === "gallery" ? "Галерея (9 экранов)" : "UI_REDESIGN_RESULT"}
            </button>
          ))}
        </div>
      </div>

      {mode === "interactive" && (
        <div className="flex gap-6 px-6 py-6">
          {/* Controls */}
          <aside className="w-[300px] shrink-0 space-y-5">
            <Panel title="Сценарий">
              <div className="flex flex-wrap gap-1.5">
                {SCENARIOS.map((s) => (
                  <Chip key={s.id} active={scenario.id === s.id} onClick={() => pick(s)}>{s.label}</Chip>
                ))}
              </div>
              <p className="mt-3 text-[12px] leading-snug text-white/45">Нажмите на орб, чтобы подключиться. В сценариях «Сбой» подключение завершится ошибкой и покажет MilkyErrorSheet вместо «(proxyerror)».</p>
            </Panel>
            <Panel title="Тема">
              <div className="flex gap-1.5">
                {(["light", "dark", "system"] as ThemeMode[]).map((m) => (
                  <Chip key={m} active={themeMode === m} onClick={() => setThemeMode(m)}>{m === "light" ? "Светлая" : m === "dark" ? "Тёмная" : "Системная"}</Chip>
                ))}
              </div>
            </Panel>
            <Panel title="Устройство">
              <div className="flex flex-col gap-1.5">
                {(Object.keys(DEVICES) as DeviceId[]).map((id) => (
                  <Chip key={id} active={device === id} onClick={() => setDevice(id)}>{DEVICES[id].label}</Chip>
                ))}
              </div>
            </Panel>
            <Panel title="Окружение">
              <Toggle label="Эмулятор (LDPlayer)" checked={isEmulator} onChange={setIsEmulator} hint="Меняет текст ошибки и класс EMULATOR_FAILURE" />
              <Toggle label="Reduce motion" checked={reduced} onChange={setReduced} hint="Отключает непрерывные анимации" />
            </Panel>
            <Panel title="Иконка приложения">
              <div className="flex items-end gap-4">
                <MilkyAppIcon size={96} />
                <MilkyAppIcon size={48} />
                <MilkyAppIcon size={32} />
              </div>
              <p className="mt-2 text-[12px] text-white/45">Капля молока + гребень «M» + аврора. Узнаваема на 48px и 32px.</p>
            </Panel>
          </aside>

          {/* Phone */}
          <main className="flex flex-1 items-start justify-center">
            <PhoneFrame device={device} scale={scale} caption={`${DEVICES[device].label} · ${theme === "dark" ? "dark" : "light"}`}>
              <MilkyApp
                key={`${key}-${device}`}
                theme={theme}
                themeMode={themeMode}
                onThemeModeChange={setThemeMode}
                preset={scenario.preset}
                failWith={scenario.failWith ?? null}
                isEmulator={isEmulator}
                reducedMotion={reduced}
                width={d.w}
                height={d.h}
              />
            </PhoneFrame>
          </main>
        </div>
      )}

      {mode === "gallery" && (
        <div className="px-6 py-6">
          <p className="mb-5 max-w-[860px] text-[13px] leading-relaxed text-white/55">
            Обязательные превью из ТЗ (1–9) плюс контрольные: импорт-успех, маленький телефон, планшет. Все экраны статичны (таймеры заморожены), но CSS-анимации живые — так видно idle/connecting/connected.
          </p>
          <div className="flex flex-wrap items-start gap-6">
            {GALLERY.map((g, i) => {
              const dd = DEVICES[g.device];
              const s = g.device === "tablet" ? 0.42 : 0.5;
              return (
                <PhoneFrame key={i} device={g.device} scale={s} caption={g.caption}>
                  <MilkyApp theme={g.theme} preset={g.preset} frozen width={dd.w} height={dd.h} />
                </PhoneFrame>
              );
            })}
          </div>
        </div>
      )}

      {mode === "report" && (
        <div className="mx-auto max-w-[900px] px-6 py-8">
          <div className="rounded-3xl border border-white/8 bg-white/4 p-6">
            <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-white/45">UI_REDESIGN_RESULT.md</div>
            <div className="mt-2 rounded-2xl border border-amber-300/20 bg-amber-300/8 p-4 text-[13.5px] leading-relaxed text-amber-100">
              <span className="font-extrabold">STATUS:</span> {REPORT_STATUS}
            </div>
            {REPORT.map((s) => (
              <section key={s.title} className="mt-8">
                <h2 className="text-[17px] font-extrabold tracking-tight">{s.title}</h2>
                <dl className="mt-3 divide-y divide-white/6 overflow-hidden rounded-2xl border border-white/8">
                  {s.rows.map(([k, v]) => (
                    <div key={k} className="grid grid-cols-[200px_1fr] gap-4 bg-white/2 px-4 py-3">
                      <dt className="text-[13px] font-bold text-white/60">{k}</dt>
                      <dd className="text-[13.5px] leading-relaxed text-white/85">{v}</dd>
                    </div>
                  ))}
                </dl>
              </section>
            ))}
            <section className="mt-8">
              <h2 className="text-[17px] font-extrabold tracking-tight">REAL DEVICE</h2>
              <ul className="mt-3 space-y-1 text-[13.5px] text-white/85">
                <li>• VPN functionality changed: <b>NO</b> (прототип затрагивает только UI-слой и маппинг ошибок)</li>
                <li>• Still requires retest: <b>YES</b> — proxyerror воспроизведён в LDPlayer; на реальном телефоне поведение может отличаться</li>
              </ul>
            </section>
          </div>
        </div>
      )}
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/8 bg-white/4 p-4">
      <div className="mb-3 text-[11.5px] font-bold uppercase tracking-[0.14em] text-white/45">{title}</div>
      {children}
    </div>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={cn("h-8 rounded-full px-3 text-[12.5px] font-bold transition-all", active ? "bg-gradient-to-r from-[#8c9dff] to-[#b593ff] text-[#0a0f22]" : "bg-white/6 text-white/70 hover:bg-white/10")}>
      {children}
    </button>
  );
}

function Toggle({ label, checked, onChange, hint }: { label: string; checked: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <button onClick={() => onChange(!checked)} className="mb-2 flex w-full items-center justify-between gap-3 text-left last:mb-0">
      <span>
        <span className="block text-[13px] font-semibold">{label}</span>
        {hint && <span className="block text-[11.5px] text-white/40">{hint}</span>}
      </span>
      <span className={cn("relative h-6 w-10 shrink-0 rounded-full transition-colors", checked ? "bg-[#8c9dff]" : "bg-white/15")}>
        <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform", checked ? "translate-x-[18px]" : "translate-x-0.5")} />
      </span>
    </button>
  );
}
