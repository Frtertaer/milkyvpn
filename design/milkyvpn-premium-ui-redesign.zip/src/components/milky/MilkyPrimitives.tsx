import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "../../utils/cn";

/* ------------------------------------------------------------------ */
/* MilkyGlassCard                                                      */
/* ------------------------------------------------------------------ */
export function MilkyGlassCard({
  children,
  className,
  strong,
  onClick,
  padding = "p-4",
}: {
  children: ReactNode;
  className?: string;
  strong?: boolean;
  onClick?: () => void;
  padding?: string;
}) {
  const Comp: any = onClick ? "button" : "div";
  return (
    <Comp
      onClick={onClick}
      className={cn(
        strong ? "glass-strong" : "glass",
        "rounded-[22px] text-left transition-transform duration-200",
        onClick && "active:scale-[0.985] cursor-pointer w-full",
        padding,
        className,
      )}
    >
      {children}
    </Comp>
  );
}

/* ------------------------------------------------------------------ */
/* MilkyPrimaryButton / MilkySecondaryButton                            */
/* ------------------------------------------------------------------ */
type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { size?: "md" | "lg"; block?: boolean };

export function MilkyPrimaryButton({ className, children, size = "lg", block = true, ...rest }: BtnProps) {
  return (
    <button
      {...rest}
      className={cn(
        "accent-gradient relative overflow-hidden rounded-full font-bold tracking-[-0.01em] transition-all duration-200",
        "active:scale-[0.98] disabled:opacity-50",
        size === "lg" ? "h-[54px] px-7 text-[16px]" : "h-[44px] px-5 text-[14px]",
        block && "w-full",
        className,
      )}
      style={{
        color: "#ffffff",
        boxShadow: "0 14px 34px -14px var(--accent), inset 0 1px 0 rgba(255,255,255,0.35)",
      }}
    >
      <span className="relative z-10">{children}</span>
      <span
        className="pointer-events-none absolute inset-0 opacity-70"
        style={{ background: "linear-gradient(180deg, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0) 55%)" }}
      />
    </button>
  );
}

export function MilkySecondaryButton({ className, children, size = "lg", block = true, ...rest }: BtnProps) {
  return (
    <button
      {...rest}
      className={cn(
        "glass-strong t-1 rounded-full font-bold tracking-[-0.01em] transition-all duration-200 active:scale-[0.98]",
        size === "lg" ? "h-[54px] px-7 text-[16px]" : "h-[44px] px-5 text-[14px]",
        block && "w-full",
        className,
      )}
    >
      {children}
    </button>
  );
}

export function MilkyTextButton({ className, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      className={cn("t-2 h-11 rounded-full px-4 text-[14px] font-semibold transition-colors hover:text-[var(--fg)] active:opacity-70", className)}
    >
      {children}
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* MilkyStatusPill                                                     */
/* ------------------------------------------------------------------ */
export function MilkyStatusPill({ tone, children, className }: { tone: "off" | "busy" | "on" | "warn"; children: ReactNode; className?: string }) {
  const dot =
    tone === "on" ? "var(--success)" : tone === "busy" ? "var(--accent)" : tone === "warn" ? "var(--warn)" : "var(--fg-3)";
  return (
    <span className={cn("glass inline-flex h-8 items-center gap-2 rounded-full px-3 text-[12.5px] font-semibold t-2", className)}>
      <span className="relative flex h-2 w-2">
        {tone !== "off" && <span className="absolute inset-0 rounded-full anim-ring-pulse" style={{ background: dot }} />}
        <span className="relative h-2 w-2 rounded-full" style={{ background: dot }} />
      </span>
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* MilkyIconButton                                                     */
/* ------------------------------------------------------------------ */
export function MilkyIconButton({ label, className, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      {...rest}
      aria-label={label}
      title={label}
      className={cn("glass t-1 flex h-10 w-10 items-center justify-center rounded-full transition-transform active:scale-95", className)}
    >
      {children}
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* MilkySettingRow                                                     */
/* ------------------------------------------------------------------ */
export function MilkySettingRow({
  icon,
  title,
  subtitle,
  trailing,
  onClick,
  last,
  danger,
}: {
  icon: ReactNode;
  title: string;
  subtitle?: string;
  trailing?: ReactNode;
  onClick?: () => void;
  last?: boolean;
  danger?: boolean;
}) {
  const Comp: any = onClick ? "button" : "div";
  return (
    <Comp
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3.5 px-4 py-3.5 text-left transition-colors",
        onClick && "active:bg-[color-mix(in_oklab,var(--fg)_6%,transparent)]",
        !last && "border-b hairline",
      )}
    >
      <span
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
        style={{
          background: danger ? "color-mix(in oklab, var(--danger) 14%, transparent)" : "color-mix(in oklab, var(--accent) 14%, transparent)",
          color: danger ? "var(--danger)" : "var(--accent)",
        }}
      >
        {icon}
      </span>
      <span className="min-w-0 flex-1">
        <span className={cn("block truncate text-[15px] font-semibold leading-tight", danger ? "t-danger" : "t-1")}>{title}</span>
        {subtitle && <span className="t-3 mt-0.5 block truncate text-[12.5px] leading-snug">{subtitle}</span>}
      </span>
      {trailing ?? (onClick ? <Chevron /> : null)}
    </Comp>
  );
}

export function MilkySectionTitle({ children }: { children: ReactNode }) {
  return <h3 className="t-3 mb-2 ml-1 text-[12px] font-bold uppercase tracking-[0.12em]">{children}</h3>;
}

/* ------------------------------------------------------------------ */
/* MilkySwitch                                                         */
/* ------------------------------------------------------------------ */
export function MilkySwitch({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="relative h-7 w-12 shrink-0 rounded-full transition-colors duration-300"
      style={{
        background: checked ? "linear-gradient(135deg, var(--accent), var(--violet))" : "color-mix(in oklab, var(--fg) 14%, transparent)",
        boxShadow: checked ? "0 6px 16px -6px var(--accent)" : "inset 0 1px 2px rgba(0,0,0,0.12)",
      }}
    >
      <span
        className="absolute top-0.5 h-6 w-6 rounded-full bg-white transition-transform duration-300"
        style={{ transform: `translateX(${checked ? 22 : 2}px)`, boxShadow: "0 2px 6px rgba(0,0,0,0.25)" }}
      />
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* Icons (inline, stroke-based, consistent 1.8 weight)                  */
/* ------------------------------------------------------------------ */
const I = ({ d, size = 20, className }: { d: ReactNode; size?: number; className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className={className}>
    {d}
  </svg>
);
export const Chevron = ({ className }: { className?: string }) => <I className={cn("t-3", className)} size={18} d={<path d="m9 6 6 6-6 6" />} />;
export const IconBack = () => <I d={<path d="m15 6-6 6 6 6" />} />;
export const IconSettings = () => <I d={<><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z" /></>} />;
export const IconHome = () => <I d={<><path d="M3 11.5 12 4l9 7.5" /><path d="M5 10v10h14V10" /></>} />;
export const IconCard = () => <I d={<><rect x="3" y="5" width="18" height="14" rx="3" /><path d="M3 10h18" /></>} />;
export const IconPower = ({ size = 28 }: { size?: number }) => <I size={size} d={<><path d="M12 3v9" /><path d="M6.3 6.3a8 8 0 1 0 11.4 0" /></>} />;
export const IconCheck = ({ size = 24, animate }: { size?: number; animate?: boolean }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
    <path className={animate ? "anim-check" : undefined} d="m5 12.5 4.5 4.5L19 7.5" />
  </svg>
);
export const IconRefresh = () => <I d={<><path d="M20 12a8 8 0 1 1-2.3-5.7" /><path d="M20 4v5h-5" /></>} />;
export const IconTrash = () => <I d={<><path d="M4 7h16" /><path d="M9 7V4h6v3" /><path d="M6 7l1 13h10l1-13" /></>} />;
export const IconBolt = () => <I d={<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z" />} />;
export const IconShield = () => <I d={<path d="M12 3 5 6v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V6l-7-3Z" />} />;
export const IconPalette = () => <I d={<><circle cx="12" cy="12" r="9" /><circle cx="8.5" cy="10.5" r="1" fill="currentColor" /><circle cx="12" cy="7.5" r="1" fill="currentColor" /><circle cx="15.5" cy="10.5" r="1" fill="currentColor" /><path d="M12 21c-1.5 0-2-1-1.5-2s2-1.3 3-.6 2.3.2 2.5-1" /></>} />;
export const IconStethoscope = () => <I d={<><path d="M4 4v6a5 5 0 0 0 10 0V4" /><path d="M9 15v2a4 4 0 0 0 8 0v-3" /><circle cx="17" cy="11" r="2" /></>} />;
export const IconChat = () => <I d={<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z" />} />;
export const IconLock = () => <I d={<><rect x="5" y="11" width="14" height="10" rx="2.5" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></>} />;
export const IconInfo = () => <I d={<><circle cx="12" cy="12" r="9" /><path d="M12 11v5" /><circle cx="12" cy="8" r="0.6" fill="currentColor" /></>} />;
export const IconLink = () => <I d={<><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1" /><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" /></>} />;
export const IconClipboard = () => <I d={<><rect x="6" y="5" width="12" height="16" rx="2.5" /><path d="M9 5a3 3 0 0 1 6 0" /><path d="M9 12h6M9 16h4" /></>} />;
export const IconCopy = () => <I d={<><rect x="9" y="9" width="11" height="11" rx="2.5" /><path d="M5 15V6.5A2.5 2.5 0 0 1 7.5 4H15" /></>} />;
export const IconPhone = () => <I d={<><rect x="7" y="2.5" width="10" height="19" rx="2.5" /><path d="M11 18h2" /></>} />;
export const IconGlobe = () => <I d={<><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" /></>} />;
export const IconArrowDown = () => <I d={<><path d="M12 4v16" /><path d="m6 14 6 6 6-6" /></>} />;
export const IconSun = () => <I d={<><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>} />;
export const IconMoon = () => <I d={<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5Z" />} />;
