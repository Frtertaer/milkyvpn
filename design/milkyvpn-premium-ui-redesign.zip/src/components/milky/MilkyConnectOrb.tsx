import type { VpnPhase } from "../../lib/types";
import { IconCheck, IconPower } from "./MilkyPrimitives";
import { cn } from "../../utils/cn";

/**
 * MilkyConnectOrb — the visual signature.
 * A milky glass sphere sitting in a soft halo.
 *  disconnected: dim, slow breathing
 *  connecting:   rotating liquid gradient ring
 *  connected:    illuminated teal/cyan ring, check mark, soft pulse ring
 *  error:        muted warm ring (no red alarm — the sheet explains)
 */
export function MilkyConnectOrb({
  phase,
  size = 236,
  onTap,
  theme,
}: {
  phase: VpnPhase;
  size?: number;
  onTap?: () => void;
  theme: "light" | "dark";
}) {
  const dark = theme === "dark";
  const connected = phase === "connected";
  const connecting = phase === "connecting";
  const error = phase === "error";

  const ringGradient = connected
    ? "conic-gradient(from 0deg, var(--success), var(--accent-2), var(--success))"
    : connecting
      ? "conic-gradient(from 0deg, transparent 0deg, var(--accent) 90deg, var(--violet) 200deg, var(--accent-2) 300deg, transparent 360deg)"
      : error
        ? "conic-gradient(from 0deg, var(--warn), rgba(255,213,138,0.2), var(--warn))"
        : "conic-gradient(from 0deg, rgba(140,157,255,0.35), rgba(181,147,255,0.15), rgba(116,230,255,0.35), rgba(140,157,255,0.35))";

  const haloColor = connected
    ? "rgba(111,232,200,0.55)"
    : connecting
      ? "rgba(140,157,255,0.55)"
      : error
        ? "rgba(255,213,138,0.32)"
        : dark
          ? "rgba(140,157,255,0.32)"
          : "rgba(91,108,255,0.28)";

  const inner = size * 0.78;

  return (
    <div className="relative flex items-center justify-center" style={{ width: size + 80, height: size + 80 }}>
      {/* soft halo */}
      <div
        className={cn("absolute rounded-full blur-2xl transition-all duration-700", !connecting && !connected && "anim-breathe")}
        style={{
          width: size * 1.05,
          height: size * 1.05,
          background: `radial-gradient(closest-side, ${haloColor}, transparent 72%)`,
          opacity: connected ? 1 : 0.9,
        }}
      />

      {/* protected pulse rings (connected only) */}
      {connected && (
        <>
          <div className="anim-ring-pulse absolute rounded-full" style={{ width: size, height: size, border: "1.5px solid var(--success)" }} />
          <div className="anim-ring-pulse absolute rounded-full" style={{ width: size, height: size, border: "1.5px solid var(--accent-2)", animationDelay: "1.4s" }} />
        </>
      )}

      {/* gradient ring */}
      <div
        className={cn("absolute rounded-full transition-all duration-700", connecting && "anim-spin", !connecting && !connected && "anim-spin-slow")}
        style={{
          width: size,
          height: size,
          background: ringGradient,
          WebkitMask: "radial-gradient(farthest-side, transparent calc(100% - 7px), #000 calc(100% - 6px))",
          mask: "radial-gradient(farthest-side, transparent calc(100% - 7px), #000 calc(100% - 6px))",
          filter: connected ? "drop-shadow(0 0 14px rgba(111,232,200,0.6))" : connecting ? "drop-shadow(0 0 10px rgba(140,157,255,0.6))" : "none",
          opacity: connected || connecting ? 1 : 0.85,
        }}
      />
      {/* secondary counter ring when connecting — "liquid" feel */}
      {connecting && (
        <div
          className="anim-spin-rev absolute rounded-full"
          style={{
            width: size * 0.9,
            height: size * 0.9,
            background: "conic-gradient(from 180deg, transparent 0deg, rgba(116,230,255,0.9) 120deg, transparent 240deg)",
            WebkitMask: "radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 2px))",
            mask: "radial-gradient(farthest-side, transparent calc(100% - 3px), #000 calc(100% - 2px))",
            opacity: 0.8,
          }}
        />
      )}

      {/* milky sphere */}
      <button
        onClick={onTap}
        aria-label={connected ? "Отключить VPN" : connecting ? "Отменить подключение" : "Подключить VPN"}
        className={cn("group relative flex items-center justify-center rounded-full transition-transform duration-300 active:scale-[0.96]", !connecting && !connected && "anim-breathe")}
        style={{
          width: inner,
          height: inner,
          background: dark
            ? "radial-gradient(circle at 32% 26%, rgba(255,255,255,0.28) 0%, rgba(255,255,255,0.08) 32%, rgba(20,28,66,0.85) 100%)"
            : "radial-gradient(circle at 32% 26%, #ffffff 0%, #f7f6ff 38%, #e6e7fb 100%)",
          boxShadow: dark
            ? `inset 0 1px 1px rgba(255,255,255,0.35), inset 0 -18px 34px rgba(0,0,0,0.35), 0 30px 60px -20px rgba(0,0,0,0.8)${connected ? ", 0 0 60px -10px rgba(111,232,200,0.5)" : ""}`
            : `inset 0 1px 1px rgba(255,255,255,1), inset 0 -18px 34px rgba(91,108,255,0.12), 0 28px 60px -22px rgba(91,108,255,0.45)${connected ? ", 0 0 60px -10px rgba(23,179,154,0.45)" : ""}`,
          border: dark ? "1px solid rgba(255,255,255,0.14)" : "1px solid rgba(255,255,255,0.9)",
          backdropFilter: "blur(14px)",
          WebkitBackdropFilter: "blur(14px)",
        }}
      >
        {/* liquid highlight */}
        <span
          className="pointer-events-none absolute rounded-full"
          style={{
            top: inner * 0.12,
            left: inner * 0.2,
            width: inner * 0.34,
            height: inner * 0.2,
            background: "linear-gradient(180deg, rgba(255,255,255,0.75), rgba(255,255,255,0))",
            filter: "blur(2px)",
            transform: "rotate(-18deg)",
          }}
        />
        {/* core icon */}
        <span
          className="relative flex items-center justify-center rounded-full transition-all duration-500"
          style={{
            width: inner * 0.42,
            height: inner * 0.42,
            background: connected
              ? "linear-gradient(135deg, var(--success), var(--accent-2))"
              : connecting
                ? "linear-gradient(135deg, var(--accent), var(--violet))"
                : dark
                  ? "rgba(255,255,255,0.08)"
                  : "rgba(91,108,255,0.10)",
            color: connected || connecting ? "#0a0f22" : "var(--accent)",
            boxShadow: connected ? "0 10px 30px -8px var(--success)" : connecting ? "0 10px 30px -8px var(--accent)" : "none",
          }}
        >
          {connected ? <IconCheck size={inner * 0.2} animate /> : <IconPower size={inner * 0.2} />}
        </span>
      </button>
    </div>
  );
}
