import { ACTION_LABEL, type ErrorAction, type UserError } from "../../lib/errors";
import { MilkyPrimaryButton, MilkySecondaryButton, MilkyTextButton } from "./MilkyPrimitives";

/**
 * MilkyErrorSheet — human message first, one primary action, one secondary,
 * diagnostics as a quiet text link. Raw codes never appear here.
 */
export function MilkyErrorSheet({
  error,
  onAction,
  onClose,
}: {
  error: UserError;
  onAction: (a: ErrorAction) => void;
  onClose: () => void;
}) {
  const [primary, secondary, ...rest] = error.actions.filter((a) => a !== "diagnostics");
  const hasDiag = error.actions.includes("diagnostics");

  return (
    <div className="absolute inset-0 z-40 flex items-end justify-center" role="dialog" aria-modal>
      <button aria-label="Закрыть" onClick={onClose} className="anim-fade absolute inset-0" style={{ background: "rgba(5,8,25,0.55)", backdropFilter: "blur(4px)" }} />
      <div
        className="anim-sheet-up glass-strong relative w-full max-w-[560px] rounded-t-[30px] px-6 pb-8 pt-3"
        style={{ borderBottom: "none" }}
      >
        <div className="mx-auto mb-5 h-1.5 w-11 rounded-full" style={{ background: "var(--fg-3)", opacity: 0.5 }} />

        {/* soft illustrative mark — a dimmed orb with a pause, not a red X */}
        <div className="anim-pop mx-auto mb-4 flex h-[72px] w-[72px] items-center justify-center rounded-full" style={{ background: "radial-gradient(circle at 35% 30%, rgba(255,255,255,0.35), color-mix(in oklab, var(--warn) 30%, transparent))", boxShadow: "0 18px 40px -16px var(--warn)" }}>
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="var(--fg)" strokeWidth={2} strokeLinecap="round">
            <path d="M12 7v6" /><circle cx="12" cy="17" r="0.9" fill="var(--fg)" />
          </svg>
        </div>

        <h2 className="t-1 text-center text-[21px] font-extrabold leading-tight tracking-[-0.02em]">{error.title}</h2>
        <p className="t-2 mx-auto mt-2 max-w-[340px] text-center text-[14px] leading-relaxed">{error.body}</p>

        <div className="mt-6 flex flex-col gap-2.5">
          {primary && <MilkyPrimaryButton onClick={() => onAction(primary)}>{ACTION_LABEL[primary]}</MilkyPrimaryButton>}
          {secondary && <MilkySecondaryButton onClick={() => onAction(secondary)}>{ACTION_LABEL[secondary]}</MilkySecondaryButton>}
          {rest.map((a) => (
            <MilkyTextButton key={a} onClick={() => onAction(a)}>
              {ACTION_LABEL[a]}
            </MilkyTextButton>
          ))}
        </div>

        {hasDiag && (
          <div className="mt-3 text-center">
            <MilkyTextButton onClick={() => onAction("diagnostics")} className="t-3 text-[13px]">
              Диагностика
            </MilkyTextButton>
          </div>
        )}
      </div>
    </div>
  );
}
