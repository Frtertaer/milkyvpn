import { cn } from "../../utils/cn";

/**
 * MilkyVPN logo mark — abstract milk droplet fused with an "M" ridge,
 * lit by a soft aurora gradient. Designed to survive 48px.
 */
export function MilkyMark({ size = 40, className, id = "m" }: { size?: number; className?: string; id?: string }) {
  const g = `milky-g-${id}`;
  const h = `milky-h-${id}`;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" className={className} aria-hidden>
      <defs>
        <linearGradient id={g} x1="8" y1="6" x2="56" y2="60" gradientUnits="userSpaceOnUse">
          <stop stopColor="#8fa0ff" />
          <stop offset="0.55" stopColor="#b48bff" />
          <stop offset="1" stopColor="#6fe3ff" />
        </linearGradient>
        <radialGradient id={h} cx="0" cy="0" r="1" gradientTransform="translate(24 20) rotate(60) scale(26)" gradientUnits="userSpaceOnUse">
          <stop stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
        </radialGradient>
      </defs>
      {/* droplet */}
      <path
        d="M32 4c9 12 20 22 20 35a20 20 0 1 1-40 0C12 26 23 16 32 4Z"
        fill={`url(#${g})`}
      />
      {/* milky highlight */}
      <path d="M32 4c9 12 20 22 20 35a20 20 0 1 1-40 0C12 26 23 16 32 4Z" fill={`url(#${h})`} />
      {/* M ridge — soft milk wave */}
      <path
        d="M17 44c3-7 6-11 9-11s5 6 6 9c1-3 3-9 6-9s6 4 9 11"
        stroke="#ffffff"
        strokeWidth="4.2"
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity="0.96"
      />
    </svg>
  );
}

/** Adaptive-icon preview: rounded squircle + mark, for the "icon" requirement. */
export function MilkyAppIcon({ size = 64, className }: { size?: number; className?: string }) {
  return (
    <div
      className={cn("relative flex items-center justify-center overflow-hidden", className)}
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.24,
        background: "radial-gradient(120% 120% at 20% 10%, #1a2350 0%, #0b1030 60%, #070a1e 100%)",
        boxShadow: "0 12px 30px -12px rgba(120,140,255,0.55), inset 0 1px 0 rgba(255,255,255,0.14)",
      }}
    >
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(60% 50% at 75% 85%, rgba(111,227,255,0.35) 0%, transparent 70%), radial-gradient(50% 50% at 20% 20%, rgba(180,139,255,0.35) 0%, transparent 70%)",
        }}
      />
      <MilkyMark size={size * 0.66} id={`icon-${size}`} />
    </div>
  );
}

export function MilkyWordmark({ className }: { className?: string }) {
  return (
    <span className={cn("t-1 font-extrabold tracking-[-0.02em]", className)}>
      Milky<span className="t-accent">VPN</span>
    </span>
  );
}
