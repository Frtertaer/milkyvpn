import type { VpnPhase } from "../../lib/types";

/**
 * Soft aurora backdrop. Intensity follows VPN phase — when connected the
 * whole screen feels alive, but it's only two blurred blobs (cheap to render).
 */
export function MilkyBackground({ phase = "disconnected", theme }: { phase?: VpnPhase; theme: "light" | "dark" }) {
  const connected = phase === "connected";
  const connecting = phase === "connecting";
  const dark = theme === "dark";

  const a = dark
    ? connected
      ? "rgba(111,232,200,0.34)"
      : "rgba(140,157,255,0.28)"
    : connected
      ? "rgba(23,179,154,0.20)"
      : "rgba(91,108,255,0.16)";
  const b = dark
    ? connected
      ? "rgba(116,230,255,0.28)"
      : "rgba(181,147,255,0.22)"
    : connected
      ? "rgba(44,197,230,0.18)"
      : "rgba(143,109,255,0.14)";

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      <div
        className="absolute inset-0"
        style={{
          background: dark
            ? "radial-gradient(120% 80% at 50% -10%, var(--bg-2) 0%, var(--bg) 60%)"
            : "radial-gradient(120% 80% at 50% -10%, #ffffff 0%, var(--bg) 65%)",
        }}
      />
      <div
        className={`absolute -left-1/4 top-[8%] h-[52%] w-[85%] rounded-full blur-3xl transition-all duration-1000 ${connecting ? "anim-aurora" : "anim-aurora"}`}
        style={{ background: `radial-gradient(closest-side, ${a}, transparent 70%)`, opacity: connected ? 1 : 0.8 }}
      />
      <div
        className="anim-aurora-2 absolute -right-1/4 top-[26%] h-[48%] w-[80%] rounded-full blur-3xl transition-all duration-1000"
        style={{ background: `radial-gradient(closest-side, ${b}, transparent 70%)`, opacity: connected ? 1 : 0.7 }}
      />
      {/* milky grain / vignette for depth */}
      <div
        className="absolute inset-0"
        style={{
          background: dark
            ? "radial-gradient(100% 70% at 50% 100%, rgba(0,0,0,0.35) 0%, transparent 60%)"
            : "radial-gradient(100% 70% at 50% 100%, rgba(91,108,255,0.06) 0%, transparent 60%)",
        }}
      />
    </div>
  );
}
