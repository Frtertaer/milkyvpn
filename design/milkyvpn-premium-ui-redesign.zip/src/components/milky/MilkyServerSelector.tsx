import { LOCATIONS, type LocationId } from "../../lib/types";
import { cn } from "../../utils/cn";

/**
 * MilkyServerSelector — compact premium chips.
 * Selected chip: gradient hairline + milky fill + soft glow.
 * Latency is only rendered if present (never invented).
 */
export function MilkyServerSelector({
  value,
  onChange,
  disabled,
  className,
}: {
  value: LocationId;
  onChange: (v: LocationId) => void;
  disabled?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("grid grid-cols-3 gap-2.5", className)} role="radiogroup" aria-label="Локация">
      {LOCATIONS.map((loc) => {
        const selected = loc.id === value;
        return (
          <button
            key={loc.id}
            role="radio"
            aria-checked={selected}
            disabled={disabled}
            onClick={() => onChange(loc.id)}
            className={cn(
              "relative flex min-h-[74px] flex-col items-start justify-between overflow-hidden rounded-[18px] px-3.5 py-3 text-left transition-all duration-300",
              "active:scale-[0.97] disabled:opacity-60",
              selected ? "glass-strong" : "glass",
            )}
            style={
              selected
                ? {
                    boxShadow: "0 18px 36px -18px var(--accent), inset 0 1px 0 var(--glass-hi)",
                    outline: "1.5px solid color-mix(in oklab, var(--accent) 65%, transparent)",
                    outlineOffset: -1.5,
                  }
                : undefined
            }
          >
            {selected && (
              <span
                className="pointer-events-none absolute inset-0 opacity-70"
                style={{ background: "radial-gradient(80% 60% at 20% 0%, color-mix(in oklab, var(--accent) 22%, transparent), transparent 70%)" }}
              />
            )}
            <span className="relative flex w-full items-center justify-between">
              <span className="text-[20px] leading-none">{loc.flag}</span>
              {selected && (
                <span className="flex h-4 w-4 items-center justify-center rounded-full accent-gradient">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3.2} strokeLinecap="round" strokeLinejoin="round">
                    <path d="m5 12.5 4.5 4.5L19 7.5" />
                  </svg>
                </span>
              )}
            </span>
            <span className="relative mt-2 block w-full">
              <span className={cn("block truncate text-[13.5px] font-bold leading-tight", selected ? "t-1" : "t-2")}>{loc.label}</span>
              <span className="t-3 mt-0.5 block text-[11px] font-medium leading-tight">
                {loc.latencyMs != null ? `${loc.latencyMs} ms` : loc.id === "auto" ? "Лучший сервер" : `${loc.profileCount} серв.`}
              </span>
            </span>
          </button>
        );
      })}
    </div>
  );
}
