import type { AppTab } from "../../lib/types";
import { IconCard, IconHome, IconSettings } from "./MilkyPrimitives";
import { cn } from "../../utils/cn";

const TABS: { id: AppTab; label: string; icon: React.ReactNode }[] = [
  { id: "home", label: "Главная", icon: <IconHome /> },
  { id: "subscription", label: "Подписка", icon: <IconCard /> },
  { id: "settings", label: "Настройки", icon: <IconSettings /> },
];

export function MilkyNavigationBar({ value, onChange }: { value: AppTab; onChange: (t: AppTab) => void }) {
  return (
    <nav
      className="mx-auto flex w-full max-w-[420px] items-center gap-1 rounded-full p-1.5"
      style={{
        background: "var(--nav-bg)",
        border: "1px solid var(--glass-border)",
        boxShadow: "var(--glass-shadow), inset 0 1px 0 var(--glass-hi)",
        backdropFilter: "blur(24px) saturate(1.5)",
        WebkitBackdropFilter: "blur(24px) saturate(1.5)",
      }}
    >
      {TABS.map((t) => {
        const active = t.id === value;
        return (
          <button
            key={t.id}
            onClick={() => onChange(t.id)}
            className={cn(
              "relative flex h-12 flex-1 items-center justify-center gap-2 rounded-full text-[13px] font-bold transition-all duration-300",
              active ? "t-1" : "t-3",
            )}
            style={
              active
                ? {
                    background: "color-mix(in oklab, var(--accent) 16%, transparent)",
                    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.25)",
                  }
                : undefined
            }
          >
            <span className={cn("transition-transform duration-300", active && "scale-105")} style={active ? { color: "var(--accent)" } : undefined}>
              {t.icon}
            </span>
            <span className={cn("overflow-hidden whitespace-nowrap transition-all duration-300", active ? "max-w-[90px] opacity-100" : "max-w-0 opacity-0")}>
              {t.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
