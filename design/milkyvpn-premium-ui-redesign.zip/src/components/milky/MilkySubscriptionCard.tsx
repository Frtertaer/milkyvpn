import type { Subscription } from "../../lib/types";
import { MilkyGlassCard, Chevron } from "./MilkyPrimitives";

export function formatDate(iso: string) {
  const d = new Date(iso);
  const months = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"];
  return `${d.getUTCDate()} ${months[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
}

/**
 * Compact home card. Truthful labels:
 *   16 профилей • 10 совместимых   (parsed vs executable — never "10 servers")
 */
export function MilkySubscriptionCard({ sub, onClick }: { sub: Subscription | null; onClick?: () => void }) {
  if (!sub) {
    return (
      <MilkyGlassCard onClick={onClick} padding="p-4">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl accent-gradient text-white text-[20px] font-black">+</span>
          <div className="min-w-0 flex-1">
            <div className="t-1 text-[15px] font-bold">Добавьте подписку</div>
            <div className="t-3 text-[12.5px]">Чтобы подключиться, нужна ссылка Milky</div>
          </div>
          <Chevron />
        </div>
      </MilkyGlassCard>
    );
  }
  const same = sub.parsedProfiles === sub.compatibleProfiles;
  return (
    <MilkyGlassCard onClick={onClick} padding="p-4">
      <div className="flex items-center gap-3.5">
        <span
          className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl"
          style={{ background: "color-mix(in oklab, var(--success) 16%, transparent)", color: "var(--success)" }}
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 3 5 6v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V6l-7-3Z" />
            <path d="m9 12 2 2 4-4" />
          </svg>
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="t-1 text-[15px] font-bold">Подписка</span>
            <span className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-bold" style={{ background: "color-mix(in oklab, var(--success) 14%, transparent)", color: "var(--success)" }}>
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: "var(--success)" }} />
              {sub.active ? "Активна" : "Истекла"}
            </span>
          </div>
          <div className="t-2 mt-0.5 truncate text-[12.5px]">
            До {formatDate(sub.expiresAt)} · {same ? `${sub.parsedProfiles} серверов` : `${sub.parsedProfiles} профилей • ${sub.compatibleProfiles} совместимых`}
          </div>
        </div>
        <Chevron />
      </div>
    </MilkyGlassCard>
  );
}
